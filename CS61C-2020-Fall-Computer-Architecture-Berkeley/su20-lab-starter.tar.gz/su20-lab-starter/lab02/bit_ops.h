unsigned get_bit(unsigned x, unsigned n);
void set_bit(unsigned * x, unsigned n, unsigned v);
void flip_bit(unsigned * x, unsigned n);